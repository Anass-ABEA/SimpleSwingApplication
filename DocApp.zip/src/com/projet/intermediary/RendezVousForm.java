package com.projet.intermediary;

import com.projet.model.Medecin;

import java.util.Date;

public class RendezVousForm {
    private Medecin medecin;
    private String motif;
    private Date date;

    public RendezVousForm(Medecin medecin, String motif, Date date) {
        this.medecin = medecin;
        this.motif = motif;
        this.date = date;
    }

    public Medecin getMedecin() {
        return medecin;
    }

    public void setMedecin(Medecin medecin) {
        this.medecin = medecin;
    }

    public String getMotif() {
        return motif;
    }

    public void setMotif(String motif) {
        this.motif = motif;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
